import discord
from discord.app_commands.translator  import CommandNameTranslationContext
from discord.ext import commands
permissoes = discord.Intents.default()
permissoes.message_content = True
permissoes.members = True
bot = commands.Bot(command_prefix=".", intents=permissoes)
@bot.command()

async def ola (ctx: commands.Context):
  print("ola")
  await ctx.reply("ola") 


 

bot.run("MTIxNzg1NTg3NjkyOTU1NjUyMQ.GhLhHN.5hhzQJYXSbBwl6YLxEOBY_hTnfDKzvt5yfItII")
